UPDATE `business_settings` SET `value` = '2.2' WHERE `business_settings`.`type` = 'current_version';

COMMIT;
