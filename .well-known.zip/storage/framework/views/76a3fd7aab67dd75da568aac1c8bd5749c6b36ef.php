<h1><?php echo e(translate('Message')); ?></h1>
<p><?php echo e($content); ?></p>
<p><b><?php echo e(translate('Sender')); ?>:</b><?php echo e($sender); ?></p>
<p><b><?php echo e(translate('Message')); ?>:</b><?php echo e($details); ?></p>
<a class="btn btn-primary btn-md" href="<?php echo e($link); ?>"><?php echo e(translate('See Details')); ?></a>
<?php /**PATH /home/wizmdxcx/public_html/resources/views/emails/conversation.blade.php ENDPATH**/ ?>